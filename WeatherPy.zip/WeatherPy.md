
# WeatherPy assessment

Objective of this project is to build a series of scatter plots to showcase the following relationships:
* Temperature (F) vs. Latitude
* Humidity (%) vs. Latitude
* Cloudiness (%) vs. Latitude
* Wind Speed (mph) vs. Latitude

Results observed:
* Temperature (F) vs. Latitude: There is a consistent pattern shown that temperature reduce as latitudes increase in both directions away from 0. 0 is the Equator. Excluding equatorial areas, temperatures are lower in the northern hemisphere compared to the southern hemisphere.
* Humidity (%) vs. Latitude: There is no consistent pattern to establish a relationship. However, the issue here may be with the method chosen to gather data. Since this was based on finding the nearest city to a randomly chosen latitutde and longitude, it is likely that the data set would have more cities along the coasts or on islands (most of the earth is water). A better method to get normally distributed data may give a different analysis.
* Cloudiness (%) vs. Latitude: There is no consistent pattern to establish a relationship.
* Wind Speed (mph) vs. Latitude: There is no consistent pattern to establish a relationship. 


```python
#import dependencies
import pandas as pd
import matplotlib.pyplot as plt
import requests
import json
import random
import time
from citipy import citipy

#config
from config import api_key
```


```python
# Randomly select **at least** 500 unique (non-repeat) cities based on latitude and longitude.


#generate a list of atleast 500 unique cities with randomly selected latitudes and longitudes using citipy
random.seed()
city_list = set([])

for i in range(0,1600):
    lat = random.randrange(-90,90,1)
    lng = random.randrange(-180,180,2)
    city = citipy.nearest_city(lat,lng)
    city_list.add(city.city_name+','+city.country_code)
         
len(city_list)
#print(city_list)
```




    627




```python
# retrieve weather data from openweathermap for selected cities


# Build base query URL
url = "http://api.openweathermap.org/data/2.5/weather?"
units = "metric"
query_url = f"{url}appid={api_key}&units={units}&q="

# intialize collections for retrieved data of interest
cities = []
countries = []
lats = []
lngs = []
dates = []
max_temps = []
cloudiness = []
humidities = []
windspeeds = []
req_count = 0

#iterate over all the randomly selected cities pulling weather data from openweathermap. Control volume not to exceeed API limits
for c in city_list:
    try:  
        city_str = c.replace(' ','+')
        final_url = query_url+city_str
        #print("Attempting to retrieve data for "+city_str)
        print(final_url)
        req_count += 1
        current_weather = requests.get(final_url).json()
        cities.append(current_weather["name"])
        countries.append(current_weather["sys"]["country"])
        dates.append(current_weather['dt'])
        lats.append(current_weather['coord']['lat'])
        lngs.append(current_weather['coord']['lon'])
        max_temps.append(current_weather['main']['temp_max'])
        cloudiness.append(current_weather['clouds']['all'])
        humidities.append(current_weather['main']['humidity'])
        windspeeds.append(current_weather['wind']['speed'])
        #break after every 55 calls to avoid going over limit
        if req_count == 56:
            print('Sleeping for a minute')
            time.sleep(60)
            req_count = 0
       
    except requests.HTTPError as err:
                print('API error for ' + c)
                print(err.reason)
    except KeyError as err:
        print ("Bad data key not found ")
        print(current_weather)
        continue
        
print('************************* Completed data pull *******************')                  
```

    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=urengoy,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=taveta,ke
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=victoria,sc
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=taybad,ir
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=wakkanai,jp
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=khatanga,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=shiyan,cn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=qinhuangdao,cn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=haldia,in
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=neman,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=sakhnovshchyna,ua
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=warmbad,za
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=sosva,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=grindavik,is
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=garhi+khairo,pk
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=abbeville,fr
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ust-nera,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kuruman,za
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=zlatoustovsk,ru
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=quesnel,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ngerengere,tz
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=sarkand,kz
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=upernavik,gl
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=faanui,pf
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=manitowoc,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=henties+bay,na
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=iqaluit,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kerema,pg
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kindersley,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=nam+tha,la
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=pingliang,cn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=vostok,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=praya,id
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=cilegon,id
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=asau,tv
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bol,td
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=vaitupu,wf
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=wolsztyn,pl
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=sentyabrskiy,ru
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=saint+george,bm
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=hofn,is
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=meyungs,pw
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=turayf,sa
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=dikson,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=khash,ir
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=palana,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=saint-pierre,pm
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tingrela,ci
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=freeport,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=airai,pw
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=pevek,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tuatapere,nz
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=beringovskiy,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=souillac,mu
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=adrian,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=perleberg,de
    Sleeping for a minute
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=zhangjiakou,cn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=los+llanos+de+aridane,es
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=hambantota,lk
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bengkulu,id
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=shingu,jp
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=san+andres,co
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=cockburn+town,bs
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=atuona,pf
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=nouadhibou,mr
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kapaa,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=pemangkat,id
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=castro,cl
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=the+valley,ai
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tumut,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ahipara,nz
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=samusu,ws
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=springbok,za
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=camana,pe
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=samalaeulu,ws
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=egvekinot,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=slantsy,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ballitoville,za
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bad+wurzach,de
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=erdenet,mn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ballina,ie
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=sorland,no
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bilaspur,in
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=susanville,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tahe,cn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=colares,pt
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=torva,ee
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=yulara,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tiarei,pf
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=grand-santi,gf
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=pandan,ph
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=cayenne,gf
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=leningradskiy,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=azangaro,pe
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=palabuhanratu,id
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=narsaq,gl
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=mbandaka,cd
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=karauzyak,uz
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=axim,gh
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kolosovka,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ulladulla,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=abu+dhabi,ae
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=porto+novo,cv
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=lavrentiya,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=waw,sd
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=igarka,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ulundi,za
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=zhezkazgan,kz
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ponta+delgada,pt
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=avera,pf
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tomohon,id
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=aykhal,ru
    Sleeping for a minute
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=lagdo,cm
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=leeton,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=lata,sb
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=seoul,kr
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=taolanaro,mg
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=manubah,tn
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=santa+rosalia,mx
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=corinto,ni
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=makakilo+city,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=samana,do
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=chimbote,pe
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=batagay,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=lardos,gr
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=punto+fijo,ve
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=hilo,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=guerrero+negro,mx
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=mokhsogollokh,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=esperance,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=shimoda,jp
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=melfi,td
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bathsheba,bb
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=merauke,id
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=motygino,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=port+hardy,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=anito,ph
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=paita,pe
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=olafsvik,is
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kargopol,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=eura,fi
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=felipe+carrillo+puerto,mx
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=necochea,ar
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=campbell+river,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=margate,za
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=mackay,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=sa+kaeo,th
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=lyuban,by
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=east+london,za
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=arroyo,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kavaratti,in
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=cape+town,za
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=grand+river+south+east,mu
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=massakory,td
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=solsvik,no
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=boali,cf
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=baruun-urt,mn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=louisbourg,ca
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=deputatskiy,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=norman+wells,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=miguelopolis,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=linxia,cn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=jamestown,sh
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=busselton,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=buqayq,sa
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ambilobe,mg
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kishanganj,in
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=akureyri,is
    Sleeping for a minute
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bondo,cd
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=provideniya,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=vestmannaeyjar,is
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=verkhnetulomskiy,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=scottsboro,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ambanja,mg
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=artyk,ru
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=plettenberg+bay,za
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=rebrikha,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=duz,tn
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=betlitsa,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=nanortalik,gl
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=sibolga,id
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bairiki,ki
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tynda,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=baykit,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=whitehorse,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=new+norfolk,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=mao,td
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ruswil,ch
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=general+pico,ar
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=yellowknife,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=roald,no
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ode,ng
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tasiilaq,gl
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=beaverlodge,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=oyama,jp
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=talas,tr
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=sioux+lookout,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bardiyah,ly
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=abilene,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=dong+hoi,vn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kabompo,zm
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=lubango,ao
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=lekoni,ga
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ploemeur,fr
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=litoral+del+san+juan,co
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=punta+arenas,cl
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=hasaki,jp
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=sao+filipe,cv
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kaka,tm
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=berberati,cf
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=gigmoto,ph
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=itarema,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=cabo+san+lucas,mx
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=portland,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=isangel,vu
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=gunjur,gm
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kruisfontein,za
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=carutapera,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tura,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=husavik,is
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=taburi,ph
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ryotsu,jp
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=saskylakh,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bluff,nz
    Sleeping for a minute
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=qaanaaq,gl
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=goure,ne
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=eyl,so
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=paso+de+los+toros,uy
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=oudtshoorn,za
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=colonial+heights,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=san+juan,ar
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=barrow,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=torbay,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bratsk,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=vanavara,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=vila+franca+do+campo,pt
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=pangkalanbuun,id
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=san+buenaventura,hn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=attawapiskat,ca
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=fairbanks,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=magugu,tz
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=lac+du+bonnet,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=garowe,so
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bossier+city,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=socorro,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ucluelet,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=matagami,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=wagar,sd
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=lorengau,pg
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ocosingo,mx
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=isla+mujeres,mx
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=trairi,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=erenhot,cn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=lyngseidet,no
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=amahai,id
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bang+len,th
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=xining,cn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=touros,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=hay+river,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=san+patricio,mx
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=alotau,pg
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=valparaiso,cl
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=sao+joao+da+barra,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bonfim,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=saint-augustin,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=malanje,ao
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=weinan,cn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=jacareacanga,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=dingli,mt
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=sindor,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=georgetown,sh
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=khonuu,ru
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=surgut,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=el+alto,pe
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=port+blair,in
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=lagoa,pt
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=marcona,pe
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=codrington,ag
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=puerto+ayora,ec
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kanjiza,rs
    Sleeping for a minute
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=basco,ph
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=taoudenni,ml
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=carmelo,uy
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=healdsburg,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=grand+centre,ca
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ambon,id
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=port+elizabeth,za
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=alice+springs,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=antofagasta,cl
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=gimli,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=hithadhoo,mv
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=selenduma,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=morropon,pe
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=novouzensk,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=chifeng,cn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=port-gentil,ga
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=davidson,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kobelyaky,ua
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=taburao,ki
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tsaratanana,mg
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=marsa+matruh,eg
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bartica,gy
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=hirara,jp
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=palmer,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=hailey,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=amparai,lk
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=broome,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=la+union,mx
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=petropavlovsk-kamchatskiy,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tocopilla,cl
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=jalu,ly
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=lompoc,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=adrar,dz
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=porto+santo,pt
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=santa+maria,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=nakamura,jp
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=anadyr,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=midrand,za
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=rosetown,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=muros,es
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=solnechnyy,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=paamiut,gl
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=chingirlau,kz
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=liverpool,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=rikitea,pf
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=amga,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=marawi,sd
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=darnah,ly
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=pascagoula,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=mazamari,pe
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kaitangata,nz
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=redwater,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=skovorodino,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tawzar,tn
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tabialan,ph
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=chuy,uy
    Sleeping for a minute
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ashqelon,il
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=mankato,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=mastic+beach,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=richard+toll,sn
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kedrovyy,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kahului,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ilulissat,gl
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=yokadouma,cm
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=paralimni,cy
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=dapdap,ph
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tambacounda,sn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=buchanan,lr
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=broken+hill,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=phan+thiet,vn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=haines+junction,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tabiauea,ki
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=roches+noires,mu
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=te+anau,nz
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=gore,et
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=victoria+point,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tutoia,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=hobart,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=thompson,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bozovici,ro
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=sao+gabriel+da+cachoeira,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=sao+felix+do+xingu,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=olga,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=dudinka,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kodiak,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=yeppoon,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ginda,er
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=pokaran,in
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tulagi,sb
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=cherskiy,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=saint+anthony,ca
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=champerico,gt
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=hamilton,bm
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tucuma,br
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=maksatikha,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=aklavik,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ketchikan,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=prince+rupert,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=gazni,af
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=yumen,cn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tuktoyaktuk,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=victor+harbor,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=calvia,es
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=zhigansk,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=najran,sa
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=mehamn,no
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=high+rock,bs
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=trelew,ar
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=gangotri,in
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kanigoro,id
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=umzimvubu,za
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=east+wenatchee,us
    Sleeping for a minute
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=hermanus,za
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ixtapa,mx
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=mount+isa,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bac+lieu,vn
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=chapais,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=nizwa,om
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kaseda,jp
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tiksi,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=jabinyanah,tn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=jacqueville,ci
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kaeo,nz
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=laem+sing,th
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=santa+eulalia+del+rio,es
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=rungata,ki
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=letterkenny,ie
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=almaznyy,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=nisia+floresta,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=divnogorsk,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ancud,cl
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ustyuzhna,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=dickinson,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=port+moresby,pg
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=saldanha,za
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=madang,pg
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tumannyy,ru
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=sigli,id
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bredasdorp,za
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=arrifes,pt
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=labuhan,id
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=awbari,ly
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=pisco,pe
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=turukhansk,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=guane,cu
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=hami,cn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=geraldton,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=rocha,uy
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=jever,de
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=namibe,ao
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=malpe,in
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=moyale,ke
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ponta+do+sol,cv
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=clyde+river,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tchollire,cm
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=agbor,ng
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=alexander+city,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=santo+tomas,pe
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=jiangyou,cn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=opuwo,na
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ternate,id
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=korla,cn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=cairns,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bethel,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kutum,sd
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=san+cristobal,ec
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=christchurch,nz
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=pratapgarh,in
    Sleeping for a minute
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tukrah,ly
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bandarbeyla,so
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=longyearbyen,sj
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=abu+jubayhah,sd
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ostrovnoy,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=point+pleasant,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=acatlan,mx
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=dunedin,nz
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=goderich,sl
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=mahbubabad,in
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=sisimiut,gl
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=balikpapan,id
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=arrecife,es
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=sosnogorsk,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=mataura,pf
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=walvis+bay,na
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=pelym,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=baixa+grande,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ulaanbaatar,mn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=les+escoumins,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=san+matias,bo
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=eldikan,ru
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=petukhovo,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=mount+gambier,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=entre+rios,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=lebu,cl
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=saint-philippe,re
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ayan,ru
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=naruja,ge
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=harper,lr
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kavieng,pg
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=deming,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=havoysund,no
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=lakes+entrance,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=dekar,bw
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=cidreira,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=hammerfest,no
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=curuca,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=xinqing,cn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=nabire,id
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=edson,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tucuman,ar
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=fortuna,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=gizo,sb
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=severo-kurilsk,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=skagastrond,is
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=launceston,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=marfino,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=charters+towers,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=magomeni,tz
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=lazurne,ua
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=blenheim,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=vaini,to
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=mys+shmidta,ru
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=dibaya,cd
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tres+arroyos,ar
    Sleeping for a minute
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=mahanoro,mg
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bukachacha,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tabou,ci
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=khanu+woralaksaburi,th
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=gat,ly
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=fort+nelson,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=aban,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=zyryanka,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=coihaique,cl
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=saint-joseph,re
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=rio+gallegos,ar
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=malindi,ke
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=panshi,cn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bambous+virieux,mu
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=slave+lake,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=cabedelo,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tabuk,sa
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=vila+velha,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=mayo,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=yenagoa,ng
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=albany,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=mporokoso,zm
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=borogontsy,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=mocambique,mz
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ushuaia,ar
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ituni,gy
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=puro,ph
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=rupert,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=chicama,pe
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=newport,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kudahuvadhoo,mv
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=plouzane,fr
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=pleasanton,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tual,id
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=arraial+do+cabo,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=richards+bay,za
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ajaccio,fr
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=mar+del+plata,ar
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=hauterive,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=illoqqortoormiut,gl
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=gandajika,cd
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=port+hedland,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=nome,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=severnyy,ru
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=mana,gf
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=jinchang,cn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=sitka,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=roros,no
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=port+macquarie,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=posse,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=elesbao+veloso,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=peace+river,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=arlit,ne
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=hobyo,so
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=sao+jose+da+coroa+grande,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=puerto+escondido,mx
    Sleeping for a minute
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=muravlenko,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=linqing,cn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=meulaboh,id
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=shenjiamen,cn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bichura,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=arshan,ru
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=sola,vu
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=mahebourg,mu
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=belushya+guba,ru
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=butaritari,ki
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=farafangana,mg
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=yuzhnyy,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=tsihombe,mg
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=aswan,eg
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=half+moon+bay,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kiunga,pg
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=pangnirtung,ca
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=vardo,no
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=clearwater,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=atambua,id
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=plastun,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=buraydah,sa
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=pravda,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=lasa,cn
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=cheuskiny,ru
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=safwah,sa
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=west+allis,us
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=methoni,gr
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=talnakh,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bambanglipuro,id
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=port+alfred,za
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=okhotsk,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=lethem,gy
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=amderma,ru
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=amapa,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=nikel,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bur+gabo,so
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=santo+antonio+do+ica,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=cananeia,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=luganville,vu
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=shache,cn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=barentsburg,sj
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=jardim,br
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=joshimath,in
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=osorheiu,ro
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ranong,th
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ust-koksa,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=zaysan,kz
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=nikolskoye,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=carnarvon,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=veraval,in
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=port+lincoln,au
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=katsuura,jp
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=nizhneyansk,ru
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=ribeira+grande,pt
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=luderitz,na
    Sleeping for a minute
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=chokurdakh,ru
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=cap+malheureux,mu
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=kopyevo,ru
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=avarua,ck
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=dakar,sn
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=inhambane,mz
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=emba,kz
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=santiago+del+estero,ar
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=biltine,td
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=bubaque,gw
    http://api.openweathermap.org/data/2.5/weather?appid=d2fe63df7207a5dc62fb2a2b5d0ce2e1&units=metric&q=mrirt,ma
    Bad data key not found 
    {'cod': '404', 'message': 'city not found'}
    ************************* Completed data pull *******************
    


```python
# put data in a dataframe to document, analyze and store

city_df = pd.DataFrame({"city":cities,
                        "country_code":countries,
                       "Lat": lats,
                       "Lng": lngs,
                        "Date": dates,
                        "Max temp": max_temps,
                       "Cloudiness": cloudiness,
                       "Humidity": humidities,
                       "Wind speed": windspeeds})
city_df.to_csv('cityweather.csv')
city_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Cloudiness</th>
      <th>Date</th>
      <th>Humidity</th>
      <th>Lat</th>
      <th>Lng</th>
      <th>Max temp</th>
      <th>Wind speed</th>
      <th>city</th>
      <th>country_code</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>48</td>
      <td>1524264333</td>
      <td>84</td>
      <td>65.96</td>
      <td>78.37</td>
      <td>-13.83</td>
      <td>1.46</td>
      <td>Urengoy</td>
      <td>RU</td>
    </tr>
    <tr>
      <th>1</th>
      <td>88</td>
      <td>1524264334</td>
      <td>98</td>
      <td>-3.40</td>
      <td>37.67</td>
      <td>19.45</td>
      <td>0.91</td>
      <td>Taveta</td>
      <td>KE</td>
    </tr>
    <tr>
      <th>2</th>
      <td>44</td>
      <td>1524261600</td>
      <td>94</td>
      <td>-4.62</td>
      <td>55.45</td>
      <td>25.00</td>
      <td>1.50</td>
      <td>Victoria</td>
      <td>SC</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>1524264334</td>
      <td>80</td>
      <td>34.74</td>
      <td>60.78</td>
      <td>4.30</td>
      <td>1.06</td>
      <td>Taybad</td>
      <td>IR</td>
    </tr>
    <tr>
      <th>4</th>
      <td>92</td>
      <td>1524264334</td>
      <td>87</td>
      <td>45.41</td>
      <td>141.67</td>
      <td>7.05</td>
      <td>11.61</td>
      <td>Wakkanai</td>
      <td>JP</td>
    </tr>
  </tbody>
</table>
</div>



# Temperature variance with latitude


```python
#Plot lat vs max temp
plt.scatter(lats, max_temps, marker="o", facecolors="red", edgecolors="black", alpha=0.75)
plt.title("Max Temp vs Latitude")
plt.xlabel("Latitude (degrees)")
plt.ylabel("Temperature (F)")
plt.show()
```


![png](output_7_0.png)


# Humidity variance with latitude


```python
#Plot lat vs humidity
plt.scatter(lats, humidities, marker="o", facecolors="blue", edgecolors="black", alpha=0.75)
plt.title("Humidity vs Latitude")
plt.xlabel("Latitude (degrees)")
plt.ylabel("Humidity (%)")
plt.show()
```


![png](output_9_0.png)


# Cloudiness variance with latitude


```python
#Plot lat vs cloudiness
plt.scatter(lats, cloudiness, marker="o", facecolors="blue", edgecolors="black", alpha=0.75)
plt.title("Cloudiness vs Latitude")
plt.xlabel("Latitude (degrees)")
plt.ylabel("Cloudiness (%)")
plt.show()
```


![png](output_11_0.png)


# Windspeed variance with latitude


```python
#Plot lat vs cloudiness
plt.scatter(lats, windspeeds, marker="o", facecolors="blue", edgecolors="black", alpha=0.75)
plt.title("Windspeed vs Latitude")
plt.xlabel("Latitude (degrees)")
plt.ylabel("Windspeed (mph)")
plt.show()
```


![png](output_13_0.png)

